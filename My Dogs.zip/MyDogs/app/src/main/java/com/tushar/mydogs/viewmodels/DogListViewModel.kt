package com.tushar.mydogs.viewmodels

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.tushar.mydogs.models.DogBreed

class DogListViewModel : ViewModel() {
    val dogs = MutableLiveData<ArrayList<DogBreed>>()
    val dogDataIsLoading = MutableLiveData<Boolean>()
    val loadingDogError = MutableLiveData<Boolean>()
    fun loadDummyData(){
        val dogList = arrayListOf(
            DogBreed(
            "Rotwailer",
            "18 Years",
            "Hunting",
            "",
            ""
        ),
        DogBreed
        (
            "Pit Bull",
            "18 Years",
            "Hunting",
            "",
            ""
        ),DogBreed
        (
                "Labrador",
                "18 Years",
                "Home",
                "",
                ""
            ))
        val isLoading = false
        val errorCaused = false
        dogs.value = dogList
        loadingDogError.value = errorCaused
        dogDataIsLoading.value = isLoading
    }
}