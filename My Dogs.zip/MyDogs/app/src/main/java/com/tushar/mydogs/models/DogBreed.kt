package com.tushar.mydogs.models

data class DogBreed(
    val dogBreedName:String,
    val dogLifeSpan:String,
    val dogUse:String,
    val dogImageUri:String,
    val dogNameUri:String
)