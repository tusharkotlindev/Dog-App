package com.tushar.mydogs

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import com.tushar.mydogs.ui.DogBreedAdapter
import com.tushar.mydogs.viewmodels.DogListViewModel
import kotlinx.android.synthetic.main.fragment_main_screen.*

class MainScreenFrag : Fragment() {
    private var dogBreedAdapter: DogBreedAdapter = DogBreedAdapter(arrayListOf(),requireContext())
    private lateinit var dogListViewModel: DogListViewModel
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        println("On Create View called")
        return inflater.inflate(R.layout.fragment_main_screen,container,false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        dogListViewModel = ViewModelProvider(this).get(DogListViewModel::class.java)
        dogListViewModel.dogs.observe(viewLifecycleOwner, Observer {
            dogBreedAdapter = DogBreedAdapter(it,requireContext())
        })
        dogListViewModel.loadDummyData()
        val recyclerView = view.findViewById<RecyclerView>(R.id.dog_recycler_view)
        recyclerView.adapter = dogBreedAdapter
        observeForDataChange()
    }
    private fun observeForDataChange(){
        dogListViewModel.dogs.observe(viewLifecycleOwner, Observer {

        })
    }
}