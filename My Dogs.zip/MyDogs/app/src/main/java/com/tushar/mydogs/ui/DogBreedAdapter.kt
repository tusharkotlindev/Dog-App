package com.tushar.mydogs.ui

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.tushar.mydogs.R
import com.tushar.mydogs.models.DogBreed

class DogBreedAdapter(private val dogData:ArrayList<DogBreed>, private val context: Context) : RecyclerView.Adapter<DogBreedAdapter.DogHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DogHolder {
        val itemView = LayoutInflater.from(context).inflate(R.layout.dog_display_card,parent,false)
        return DogHolder(itemView)
    }
    override fun getItemCount(): Int {
        return dogData.size
    }
    override fun onBindViewHolder(holder: DogHolder, position: Int) {
        val textView = holder.itemView.findViewById<TextView>(R.id.dog_name_text_view)
        textView.text = dogData[position].dogBreedName
    }
    class DogHolder(itemView:View) : RecyclerView.ViewHolder(itemView)
    // this method will be called when the data will be updated
    fun updateTheData(updatedDogs:ArrayList<DogBreed>) {
        updatedDogs.clear()
        updatedDogs.addAll(updatedDogs)
        notifyDataSetChanged()
    }
}